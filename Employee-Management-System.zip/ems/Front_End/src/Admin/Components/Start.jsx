import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Start = () => {
  const navigate = useNavigate();
  axios.defaults.withCredentials = true;

  useEffect(() => {
    axios.get("http://localhost:5000/auth/verify")
      .then((result) => {
        if (result.data.Status) {
          if (result.data.role === "admin") navigate("/dashboard");
          else navigate("/employee");
        }
      })
      .catch(() => {});
  }, []);

  return (
    <div className="mainPage">
      {/* Hero */}
      <div className="heroSection">
        <div className="overlay">
          <h1>Employee Management System</h1>
          <p>Streamline HR operations — attendance, leaves, payroll, and more in one place.</p>
          <div className="heroButtons">
            <button className="employeeBtn" onClick={() => navigate("/employee_login")}>
              👤 Employee Login
            </button>
            <button className="adminBtn" onClick={() => navigate("/adminlogin")}>
              🛡️ Admin Login
            </button>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="featuresSection">
        <h2 className="sectionTitle">What We Offer</h2>
        <div className="featuresGrid">
          {[
            { icon: "📊", title: "Dashboard Analytics", desc: "Get real-time insights on employees, attendance, and payroll." },
            { icon: "👥", title: "Employee Management", desc: "Add, edit, view, and manage all employee records effortlessly." },
            { icon: "🗓️", title: "Attendance Tracking", desc: "Mark and monitor daily attendance with detailed reports." },
            { icon: "📋", title: "Leave Management", desc: "Apply and approve leave requests with full workflow support." },
            { icon: "💰", title: "Payroll Management", desc: "Generate payslips and manage salary disbursements." },
            { icon: "🔐", title: "Secure Portals", desc: "Separate secure portals for admins and employees." },
          ].map((f) => (
            <div className="featureCard" key={f.title}>
              <div className="icon">{f.icon}</div>
              <h3>{f.title}</h3>
              <p>{f.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* About */}
      <div className="aboutSection">
        <h2>About This System</h2>
        <p>
          Our Employee Management System is designed to help organizations efficiently manage their workforce.
          From onboarding to payroll, we provide a complete suite of HR tools that saves time and increases
          productivity for both administrators and employees.
        </p>
      </div>

      {/* Footer */}
      <footer className="footer">
        <marquee scrollamount="4">
          © 2026 Employee Management System | Developed by Sanika Bajarang Jadhav
        </marquee>
      </footer>
    </div>
  );
};

export default Start;
